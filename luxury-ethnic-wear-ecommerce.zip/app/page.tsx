import App from "../Luxury-Ethnic-Wear-E-commerce"

export default function Page() {
  return <App />
}
